import { NextRequest, NextResponse } from 'next/server'

const TOOL_DATABASE: Record<string, Array<{
  name: string
  category: string
  useCase: string
  link: string
  description: string
}>> = {
  'Frontend Framework': [
    {
      name: 'React',
      category: 'Frontend',
      useCase: 'Build interactive user interfaces with components',
      link: 'https://react.dev',
      description: 'A JavaScript library for building user interfaces with reusable components',
    },
    {
      name: 'Vue.js',
      category: 'Frontend',
      useCase: 'Progressive JavaScript framework for UIs',
      link: 'https://vuejs.org',
      description: 'An approachable, performant and versatile framework for building user interfaces',
    },
    {
      name: 'Angular',
      category: 'Frontend',
      useCase: 'Full-featured framework for large applications',
      link: 'https://angular.io',
      description: 'A platform for building mobile and desktop web applications',
    },
  ],
  'Backend Framework': [
    {
      name: 'Next.js',
      category: 'Backend',
      useCase: 'Full-stack React framework with API routes',
      link: 'https://nextjs.org',
      description: 'The React Framework for Production with built-in API routes and deployment',
    },
    {
      name: 'Express.js',
      category: 'Backend',
      useCase: 'Lightweight Node.js server framework',
      link: 'https://expressjs.com',
      description: 'Fast, unopinionated, minimalist web framework for Node.js',
    },
    {
      name: 'Django',
      category: 'Backend',
      useCase: 'Full-featured Python web framework',
      link: 'https://www.djangoproject.com',
      description: 'The web framework for perfectionists with deadlines',
    },
  ],
  'Database': [
    {
      name: 'PostgreSQL',
      category: 'Database',
      useCase: 'Powerful open-source relational database',
      link: 'https://www.postgresql.org',
      description: 'The World\'s Most Advanced Open Source Relational Database',
    },
    {
      name: 'MongoDB',
      category: 'Database',
      useCase: 'NoSQL document database for flexible schemas',
      link: 'https://www.mongodb.com',
      description: 'The most popular database for modern apps',
    },
    {
      name: 'Supabase',
      category: 'Database',
      useCase: 'Open source Firebase alternative with PostgreSQL',
      link: 'https://supabase.com',
      description: 'The open source Firebase alternative with a PostgreSQL database',
    },
  ],
  'Authentication': [
    {
      name: 'Auth.js',
      category: 'Authentication',
      useCase: 'Flexible authentication for Next.js',
      link: 'https://authjs.dev',
      description: 'Authentication for the web and beyond. Simple and secure.',
    },
    {
      name: 'Firebase Auth',
      category: 'Authentication',
      useCase: 'Cloud-based authentication service',
      link: 'https://firebase.google.com/products/auth',
      description: 'Easy-to-use authentication & authorization platform',
    },
    {
      name: 'Clerk',
      category: 'Authentication',
      useCase: 'Modern authentication for web and mobile',
      link: 'https://clerk.com',
      description: 'The easiest way to add authentication to your application',
    },
  ],
  'Real-time Communication': [
    {
      name: 'Socket.io',
      category: 'Real-time',
      useCase: 'Bidirectional communication with WebSockets',
      link: 'https://socket.io',
      description: 'Real-time bidirectional event-based communication',
    },
    {
      name: 'Supabase Realtime',
      category: 'Real-time',
      useCase: 'Real-time data synchronization',
      link: 'https://supabase.com/docs/guides/realtime',
      description: 'Real-time database subscriptions powered by PostgreSQL',
    },
    {
      name: 'Firebase Realtime DB',
      category: 'Real-time',
      useCase: 'Cloud-hosted NoSQL real-time database',
      link: 'https://firebase.google.com/docs/database',
      description: 'Store and sync data with our NoSQL cloud database',
    },
  ],
  'CSS Framework': [
    {
      name: 'Tailwind CSS',
      category: 'Styling',
      useCase: 'Utility-first CSS framework',
      link: 'https://tailwindcss.com',
      description: 'A utility-first CSS framework for rapidly building custom designs',
    },
    {
      name: 'Bootstrap',
      category: 'Styling',
      useCase: 'Popular responsive CSS framework',
      link: 'https://getbootstrap.com',
      description: 'Powerful, extensible, and feature-packed frontend toolkit',
    },
    {
      name: 'Shadcn/ui',
      category: 'Styling',
      useCase: 'Re-usable components built with Radix UI and Tailwind CSS',
      link: 'https://ui.shadcn.com',
      description: 'Beautifully designed components that you can copy and paste',
    },
  ],
  'Testing Framework': [
    {
      name: 'Jest',
      category: 'Testing',
      useCase: 'Complete JavaScript testing framework',
      link: 'https://jestjs.io',
      description: 'Delightful JavaScript Testing Framework with a focus on simplicity',
    },
    {
      name: 'Vitest',
      category: 'Testing',
      useCase: 'Unit test framework powered by Vite',
      link: 'https://vitest.dev',
      description: 'Next generation unit test framework powered by Vite',
    },
    {
      name: 'Playwright',
      category: 'Testing',
      useCase: 'End-to-end testing framework',
      link: 'https://playwright.dev',
      description: 'Playwright enables reliable end-to-end testing for modern web apps',
    },
  ],
  'Hosting': [
    {
      name: 'Vercel',
      category: 'Hosting',
      useCase: 'Optimized hosting for Next.js and frontend',
      link: 'https://vercel.com',
      description: 'The platform for frontend developers',
    },
    {
      name: 'Netlify',
      category: 'Hosting',
      useCase: 'Modern web development platform',
      link: 'https://netlify.com',
      description: 'The platform built for modern web teams',
    },
    {
      name: 'Railway',
      category: 'Hosting',
      useCase: 'Infrastructure platform for full-stack applications',
      link: 'https://railway.app',
      description: 'Modern infrastructure platform. Build and ship apps.',
    },
  ],
}

export async function POST(request: NextRequest) {
  try {
    const { requirements } = await request.json()

    if (!Array.isArray(requirements)) {
      return NextResponse.json(
        { error: 'Requirements must be an array' },
        { status: 400 }
      )
    }

    const tools: Array<{
      id: string
      name: string
      category: string
      useCase: string
      link: string
      description: string
    }> = []

    // Get tools for each requirement
    for (const req of requirements) {
      const toolsForReq = TOOL_DATABASE[req] || []
      tools.push(
        ...toolsForReq.map((tool, idx) => ({
          id: `${req}-${idx}`,
          ...tool,
        }))
      )
    }

    return NextResponse.json(tools)
  } catch (error) {
    console.error('Recommend error:', error)
    return NextResponse.json(
      { error: 'Failed to get recommendations' },
      { status: 500 }
    )
  }
}
